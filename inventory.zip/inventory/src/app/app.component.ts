import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { ChartConfiguration, ChartOptions } from 'chart.js';


interface DataItem{
  Month: string;
  'Primary product': number;
  'Secondary product': number;
}
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})


export class AppComponent implements OnInit{
  title = 'inventory';
  chartData: ChartConfiguration<'bar'>['data']= {
    labels: [],
    datasets: [
      {data: [], label: 'Primary products'},
      {data: [], label: 'Secondary products'},
    ]
  };
  chartOptions: ChartOptions<'bar'> ={
    responsive: true,
  };
barChartLegend: any;

  constructor(private http: HttpClient){}

  ngOnInit(){
    this.fetchData();
  }

  fetchData(){
    this.http.get<DataItem[]>('http://localhost:8081/api/data').subscribe(
      (data) => {
        this.chartData.labels =data.map(item => item.Month);
        this.chartData.datasets[0].data = data.map(item => item['Primary product']);
        this.chartData.datasets[0].data = data.map(item => item['Secondary product']);
      },
      (error) =>{
        console.error('Error', error);
      }
    );
  }

  downloadExcel(){
    window.open('http://localhost:8081/api/download/excel');
  }

  async downloadPdf(){
    const {jsPDF}= await import('jspdf');
    const html2canvasModule = await import('html2canvas')
    const html2canvas = html2canvasModule.default
     const chartElement = document.querySelector('canvas');
    if(chartElement){
      html2canvas(chartElement).then((canvas: any) =>{
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF('landscape');
        const imgProps = pdf.getImageProperties(imgData);
        const pdfWidth =pdf.internal.pageSize.getWidth();
        const pdfHeight = (imgProps.height* pdfWidth/ imgProps.width);
        pdf.addImage(imgData, 'PNG',0,0, pdfWidth,pdfHeight);
        pdf.save('chart.pdf');
      })
  }else{
    console.error('chart not found');
  }
  }
 
}
